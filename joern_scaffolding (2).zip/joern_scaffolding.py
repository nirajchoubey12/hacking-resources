"""
Joern Scaffolding Layer for LLM-Driven Security Analysis
=========================================================

Setup:
  brew install joern
  pip install cpgqls-client

Start Joern server:
  joern --server --server-host localhost --server-port 8080

Usage:
  from joern_scaffolding import JoernScaffold

  joern = JoernScaffold()
  joern.import_code("/path/to/cloned/repo", language="javasrc")
  result = joern.get_method_source("findUser")
"""

import json
import re
import logging
from typing import Optional
from dataclasses import dataclass, field, asdict
from cpgqls_client import CPGQLSClient, import_code_query

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("joern_scaffold")


# ─── Data Models ───

@dataclass
class MethodInfo:
    name: str
    full_name: str = ""
    file: str = ""
    line: int = 0
    signature: str = ""

@dataclass
class ParameterInfo:
    name: str
    type: str = ""
    index: int = 0

@dataclass
class CallInfo:
    name: str
    full_name: str = ""
    file: str = ""
    line: int = 0
    code: str = ""

@dataclass
class AssignmentInfo:
    code: str
    line: int = 0
    file: str = ""

@dataclass
class FlowStep:
    code: str
    line: int = 0
    file: str = ""
    node_type: str = ""

@dataclass
class TaintFlowResult:
    flow_exists: bool
    paths: list = field(default_factory=list)

@dataclass
class SanitizationResult:
    flow_exists: bool
    passes_through_sanitizer: bool
    sanitizer_name: str = ""


# ─── Joern Query Result Parser ───

class JoernResultParser:
    """Parses raw Joern stdout into structured Python objects."""

    @staticmethod
    def parse_raw(result: dict) -> str:
        """Extract stdout from Joern response."""
        if isinstance(result, dict):
            return result.get("stdout", "")
        return str(result)

    @staticmethod
    def parse_list(raw: str) -> list:
        """Parse Joern List output into Python list."""
        raw = raw.strip()
        if not raw or raw == "List()" or raw == "val res" in raw and "List()" in raw:
            return []
        # Try JSON-like parsing for tuples
        try:
            # Joern often returns List(("a", "b", 1), ("c", "d", 2))
            # Extract content between outer List(...)
            match = re.search(r'List\((.*)\)', raw, re.DOTALL)
            if match:
                content = match.group(1)
                # Split by tuple boundaries
                tuples = re.findall(r'\(([^)]+)\)', content)
                return [t.strip() for t in tuples] if tuples else [content.strip()]
        except Exception:
            pass
        return [raw]

    @staticmethod
    def parse_bool(raw: str) -> bool:
        """Parse Joern boolean output."""
        raw = raw.strip().lower()
        return "true" in raw


# ─── Main Scaffolding Layer ───

class JoernScaffold:
    """
    Abstraction layer between LLM tool calls and Joern's Scala DSL.

    The LLM calls simple Python methods with string parameters.
    This layer translates them into Joern queries, executes them,
    and returns structured JSON-friendly results.
    """

    def __init__(self, host: str = "localhost", port: int = 8080,
                 auth: tuple = None):
        """
        Connect to a running Joern server.

        Args:
            host: Joern server hostname
            port: Joern server port
            auth: Optional (username, password) tuple
        """
        endpoint = f"{host}:{port}"
        self.client = CPGQLSClient(endpoint, auth_credentials=auth)
        self.parser = JoernResultParser()
        self._project_loaded = False
        logger.info(f"Connected to Joern server at {endpoint}")

    def _execute(self, query: str) -> str:
        """Execute a Joern query and return raw stdout."""
        logger.debug(f"Joern query: {query}")
        try:
            result = self.client.execute(query)
            raw = self.parser.parse_raw(result)
            logger.debug(f"Joern result: {raw[:200]}")
            return raw
        except Exception as e:
            logger.error(f"Joern query failed: {e}")
            return ""

    # ─── Project Management ───

    def import_code(self, path: str, language: str = "javasrc",
                    project_name: str = "analysis") -> dict:
        """
        Import a codebase and generate the CPG.

        Args:
            path: Absolute path to the cloned repository
            language: Language frontend (javasrc, jssrc, pysrc, c, etc.)
            project_name: Name for this analysis workspace

        Returns:
            {"success": bool, "message": str}
        """
        query = import_code_query(path, project_name)
        result = self._execute(query)
        self._project_loaded = "Cpg" in result or "cpg" in result.lower()
        return {
            "success": self._project_loaded,
            "message": result.strip()[:200]
        }

    def close_project(self) -> dict:
        """Unload the current CPG and free memory."""
        result = self._execute("workspace.reset")
        self._project_loaded = False
        return {"success": True, "message": "Workspace reset"}

    # ─── Tool 1: Get Method Source ───

    def get_method_source(self, method_name: str) -> dict:
        """
        Get the full source code of a method.

        USE WHEN: You need to read the actual code to understand what
        a function does — identify variables, calls, and logic.

        Args:
            method_name: Name of the method (e.g., "findUser")

        Returns:
            {"name": str, "file": str, "line": int, "source": str}
        """
        query = (
            f'cpg.method.name("{method_name}")'
            f'.map(m => (m.name, m.filename, m.lineNumber.getOrElse(-1), m.code)).l'
        )
        raw = self._execute(query)

        # Also get the full method body via AST
        body_query = (
            f'cpg.method.name("{method_name}").ast.code.l.mkString("\\n")'
        )
        body = self._execute(body_query)

        return {
            "name": method_name,
            "info": raw.strip()[:500],
            "source": body.strip()[:2000],
            "_hint": "Read the source to identify variables, calls, and data flow patterns"
        }

    # ─── Tool 2: Get Callers ───

    def get_callers(self, method_name: str) -> dict:
        """
        Find all methods that call the target method.

        USE WHEN: Tracing BACKWARD — "where does the data come from?"
        After finding a dangerous sink, use this to find who passes data to it.

        Args:
            method_name: Name of the method to find callers for

        Returns:
            {"method": str, "callers": [{"name", "file", "line", "code"}]}
        """
        query = (
            f'cpg.method.name("{method_name}").caller'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename, '
            f'"line" -> m.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        raw = self._execute(query)

        # Also get the call-site code for context
        callsite_query = (
            f'cpg.method.name("{method_name}").callIn'
            f'.map(c => Map('
            f'"caller_method" -> c.method.name, '
            f'"code" -> c.code, '
            f'"file" -> c.file.name.headOption.getOrElse("unknown"), '
            f'"line" -> c.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        callsites = self._execute(callsite_query)

        return {
            "method": method_name,
            "callers": raw.strip()[:1000],
            "call_sites": callsites.strip()[:1000],
            "_hint": "To continue tracing backward, call get_method_source on each caller"
        }

    # ─── Tool 3: Get Callees ───

    def get_callees(self, method_name: str) -> dict:
        """
        Find all methods called by the target method.

        USE WHEN: Tracing FORWARD — "where does the data go?"
        To understand what operations a method performs.

        Args:
            method_name: Name of the method to find callees for

        Returns:
            {"method": str, "callees": [{"name", "file", "line"}]}
        """
        query = (
            f'cpg.method.name("{method_name}").callee'
            f'.filterNot(_.isExternal)'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename, '
            f'"line" -> m.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        raw = self._execute(query)

        # Also get external calls (library/framework calls)
        ext_query = (
            f'cpg.method.name("{method_name}").call'
            f'.map(c => Map('
            f'"name" -> c.name, '
            f'"code" -> c.code, '
            f'"line" -> c.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        ext_calls = self._execute(ext_query)

        return {
            "method": method_name,
            "internal_callees": raw.strip()[:1000],
            "all_calls": ext_calls.strip()[:1500],
            "_hint": "Look for dangerous sinks: execute, eval, exec, open, redirect, write"
        }

    # ─── Tool 4: Get Parameters ───

    def get_parameters(self, method_name: str) -> dict:
        """
        Get parameter names and types for a method.

        USE WHEN: You need to know what data a method receives
        and what types it expects.

        Args:
            method_name: Name of the method

        Returns:
            {"method": str, "parameters": [{"name", "type", "index"}]}
        """
        query = (
            f'cpg.method.name("{method_name}").parameter'
            f'.map(p => Map('
            f'"name" -> p.name, '
            f'"type" -> p.typeFullName, '
            f'"index" -> p.index.toString'
            f')).toJson'
        )
        raw = self._execute(query)

        return {
            "method": method_name,
            "parameters": raw.strip()[:1000],
            "_hint": "Check if any parameter type is String — those can carry tainted data"
        }

    # ─── Tool 5: Find Taint Flow (THE KEY TOOL) ───

    def find_taint_flow(self, source_pattern: str, sink_pattern: str) -> dict:
        """
        Check if data flows from a source to a sink across the codebase.

        USE WHEN: You've identified a potential source (e.g., getParameter)
        and a potential sink (e.g., executeQuery) and want to know if
        tainted data can actually reach the sink.

        This is the most powerful tool — it does cross-file interprocedural
        taint tracking automatically.

        Args:
            source_pattern: Name pattern for the source method
                           (e.g., "getParameter", "getHeader", "readLine")
            sink_pattern: Name pattern for the sink method
                         (e.g., "executeQuery", "exec", "eval", "redirect")

        Returns:
            {"flow_exists": bool, "paths": [list of flow steps]}
        """
        # First: check if any flow exists
        exists_query = (
            f'def source = cpg.call.name("{source_pattern}")\\n'
            f'def sink = cpg.call.name("{sink_pattern}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        exists_raw = self._execute(exists_query)
        flow_exists = self.parser.parse_bool(exists_raw)

        paths = []
        if flow_exists:
            # Get the detailed flow paths
            flow_query = (
                f'def source = cpg.call.name("{source_pattern}")\\n'
                f'def sink = cpg.call.name("{sink_pattern}")\\n'
                f'sink.reachableBy(source).flows'
                f'.map(f => f.elements.map(e => Map('
                f'"code" -> e.code, '
                f'"line" -> e.lineNumber.getOrElse(-1).toString, '
                f'"file" -> e.file.name.headOption.getOrElse("unknown"), '
                f'"node_type" -> e.label'
                f'))).toJson'
            )
            paths_raw = self._execute(flow_query)
            paths = paths_raw.strip()[:3000]

        return {
            "source_pattern": source_pattern,
            "sink_pattern": sink_pattern,
            "flow_exists": flow_exists,
            "paths": paths if paths else "No flow found",
            "_hint": (
                "If flow_exists is true, examine the path to understand how data "
                "moves from source to sink. If false, the concern is likely a false positive."
            )
        }

    # ─── Tool 6: Find Taint Flow with Full Name Matching ───

    def find_taint_flow_fullname(self, source_fullname: str,
                                  sink_fullname: str) -> dict:
        """
        Like find_taint_flow but uses full method name regex matching.

        USE WHEN: Simple name matching returns too many results or
        you need to target a specific class/package.

        Args:
            source_fullname: Regex for source full name
                            (e.g., "javax.servlet.*getParameter.*")
            sink_fullname: Regex for sink full name
                          (e.g., "java.sql.Statement.execute.*")

        Returns:
            {"flow_exists": bool, "paths": [...]}
        """
        exists_query = (
            f'def source = cpg.call.methodFullName("{source_fullname}")\\n'
            f'def sink = cpg.call.methodFullName("{sink_fullname}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        exists_raw = self._execute(exists_query)
        flow_exists = self.parser.parse_bool(exists_raw)

        paths = []
        if flow_exists:
            flow_query = (
                f'def source = cpg.call.methodFullName("{source_fullname}")\\n'
                f'def sink = cpg.call.methodFullName("{sink_fullname}")\\n'
                f'sink.reachableBy(source).flows'
                f'.map(f => f.elements.map(e => Map('
                f'"code" -> e.code, '
                f'"line" -> e.lineNumber.getOrElse(-1).toString, '
                f'"file" -> e.file.name.headOption.getOrElse("unknown")'
                f'))).toJson'
            )
            paths = self._execute(flow_query).strip()[:3000]

        return {
            "source_pattern": source_fullname,
            "sink_pattern": sink_fullname,
            "flow_exists": flow_exists,
            "paths": paths if paths else "No flow found"
        }

    # ─── Tool 7: Check Sanitization ───

    def check_sanitization(self, source_pattern: str, sink_pattern: str,
                           sanitizer_pattern: str) -> dict:
        """
        Check if a taint flow passes through a sanitization function.

        USE WHEN: You've confirmed a flow exists and want to check if
        there's a sanitizer in the path that might make it safe.

        Args:
            source_pattern: Source method name (e.g., "getParameter")
            sink_pattern: Sink method name (e.g., "executeQuery")
            sanitizer_pattern: Sanitizer name regex
                              (e.g., "sanitize|escape|validate|encode|clean")

        Returns:
            {"flow_exists": bool, "passes_through_sanitizer": bool}
        """
        # Check if any flow exists at all
        exists_query = (
            f'def source = cpg.call.name("{source_pattern}")\\n'
            f'def sink = cpg.call.name("{sink_pattern}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        flow_exists = self.parser.parse_bool(self._execute(exists_query))

        passes_sanitizer = False
        if flow_exists:
            # Check if ANY flow passes through the sanitizer
            sanitized_query = (
                f'def source = cpg.call.name("{source_pattern}")\\n'
                f'def sink = cpg.call.name("{sink_pattern}")\\n'
                f'sink.reachableBy(source).flows'
                f'.filter(_.elements.isCall.name("{sanitizer_pattern}").nonEmpty)'
                f'.l.nonEmpty'
            )
            passes_sanitizer = self.parser.parse_bool(
                self._execute(sanitized_query)
            )

        return {
            "source": source_pattern,
            "sink": sink_pattern,
            "sanitizer": sanitizer_pattern,
            "flow_exists": flow_exists,
            "passes_through_sanitizer": passes_sanitizer,
            "verdict": (
                "SAFE — flow passes through sanitizer" if passes_sanitizer
                else "VULNERABLE — flow exists without sanitization"
                if flow_exists else "NO FLOW — no data path from source to sink"
            ),
            "_hint": (
                "If VULNERABLE, report as confirmed finding. "
                "If SAFE, verify the sanitizer is appropriate for the sink type "
                "(e.g., HTML encoding doesn't prevent SQLi)."
            )
        }

    # ─── Tool 8: Get Assignments ───

    def get_assignments(self, variable: str, method_name: str) -> dict:
        """
        Find all assignments to a variable within a method.

        USE WHEN: You need to track how a variable is transformed
        between source and sink within a single method.

        Args:
            variable: Variable name to track (e.g., "query", "userId")
            method_name: Method to search within

        Returns:
            {"variable": str, "assignments": [{"code", "line"}]}
        """
        query = (
            f'cpg.method.name("{method_name}").ast.isCall'
            f'.name("<operator>.assignment")'
            f'.filter(_.argument(1).code(".*{variable}.*"))'
            f'.map(a => Map('
            f'"code" -> a.code, '
            f'"line" -> a.lineNumber.getOrElse(-1).toString, '
            f'"file" -> a.file.name.headOption.getOrElse("unknown")'
            f')).toJson'
        )
        raw = self._execute(query)

        return {
            "variable": variable,
            "method": method_name,
            "assignments": raw.strip()[:1500],
            "_hint": (
                "Look for string concatenation with tainted variables, "
                "or re-assignment after sanitization (sanitize-then-modify pattern)"
            )
        }

    # ─── Tool 9: Get Usages ───

    def get_usages(self, symbol: str, method_name: str = None) -> dict:
        """
        Find all places where a symbol (variable/method) is referenced.

        USE WHEN: You need to know everywhere a tainted variable is
        used — it might reach multiple sinks.

        Args:
            symbol: Symbol name to search for
            method_name: Optional — restrict search to a specific method

        Returns:
            {"symbol": str, "usages": [{"code", "line", "file"}]}
        """
        if method_name:
            query = (
                f'cpg.method.name("{method_name}").ast.isIdentifier'
                f'.name("{symbol}")'
                f'.map(i => Map('
                f'"code" -> i.inAstMinusLeaf.headOption.map(_.code).getOrElse(i.code), '
                f'"line" -> i.lineNumber.getOrElse(-1).toString, '
                f'"file" -> i.file.name.headOption.getOrElse("unknown")'
                f')).toJson'
            )
        else:
            query = (
                f'cpg.identifier.name("{symbol}")'
                f'.map(i => Map('
                f'"code" -> i.inAstMinusLeaf.headOption.map(_.code).getOrElse(i.code), '
                f'"line" -> i.lineNumber.getOrElse(-1).toString, '
                f'"file" -> i.file.name.headOption.getOrElse("unknown"), '
                f'"method" -> i.method.name'
                f')).toJson'
            )
        raw = self._execute(query)

        return {
            "symbol": symbol,
            "scope": method_name or "global",
            "usages": raw.strip()[:2000]
        }

    # ─── Tool 10: Get Imports ───

    def get_imports(self, file_path: str) -> dict:
        """
        Get all imports/includes in a file.

        USE WHEN: Checking what sanitization libraries or frameworks
        are available in a file. Also useful for identifying if an
        ORM or security wrapper is in use.

        Args:
            file_path: Path pattern for the file (can be partial)

        Returns:
            {"file": str, "imports": [str]}
        """
        query = (
            f'cpg.file.name(".*{file_path}.*").ast.isCall'
            f'.name("<operator>.import")'
            f'.code.l'
        )
        raw = self._execute(query)

        # Fallback: look for import declarations
        if not raw.strip() or "List()" in raw:
            query = (
                f'cpg.file.name(".*{file_path}.*")'
                f'.ast.filter(_.label == "IMPORT")'
                f'.code.l'
            )
            raw = self._execute(query)

        return {
            "file": file_path,
            "imports": raw.strip()[:2000],
            "_hint": (
                "Look for security-related imports: sanitizers, validators, "
                "ORM libraries, prepared statement classes"
            )
        }

    # ─── Tool 11: Get Decorators / Annotations ───

    def get_annotations(self, method_name: str) -> dict:
        """
        Get annotations/decorators on a method.

        USE WHEN: Checking for security annotations like @Validated,
        @Sanitized, @PreAuthorize, @RolesAllowed, etc.

        Args:
            method_name: Method to check

        Returns:
            {"method": str, "annotations": [str]}
        """
        query = (
            f'cpg.method.name("{method_name}").annotation'
            f'.map(a => Map('
            f'"name" -> a.name, '
            f'"code" -> a.code'
            f')).toJson'
        )
        raw = self._execute(query)

        return {
            "method": method_name,
            "annotations": raw.strip()[:1000],
            "_hint": (
                "Security annotations like @PreAuthorize, @Valid, @Sanitized "
                "may indicate framework-level protection"
            )
        }

    # ─── Tool 12: Find Pattern ───

    def find_pattern(self, pattern: str, file_pattern: str = ".*") -> dict:
        """
        Search for a code pattern across the codebase.

        USE WHEN: Looking for all instances of a dangerous pattern
        like raw SQL construction, eval usage, or hardcoded secrets.

        Args:
            pattern: Code pattern to search for (regex)
            file_pattern: Optional file path filter (regex)

        Returns:
            {"pattern": str, "matches": [{"code", "line", "file", "method"}]}
        """
        query = (
            f'cpg.call.code(".*{pattern}.*")'
            f'.filter(_.file.name(".*{file_pattern}.*"))'
            f'.map(c => Map('
            f'"code" -> c.code, '
            f'"line" -> c.lineNumber.getOrElse(-1).toString, '
            f'"file" -> c.file.name.headOption.getOrElse("unknown"), '
            f'"method" -> c.method.name'
            f')).toJson'
        )
        raw = self._execute(query)

        return {
            "pattern": pattern,
            "file_filter": file_pattern,
            "matches": raw.strip()[:2000]
        }

    # ─── Tool 13: Get Method by File and Line ───

    def get_method_at_location(self, file_path: str, line: int) -> dict:
        """
        Find the method that contains a specific line of code.

        USE WHEN: Agent 1 gives you a file:line reference and you
        need to know which method it belongs to.

        Args:
            file_path: File path (partial match supported)
            line: Line number

        Returns:
            {"file": str, "line": int, "method": {"name", "full_name", "start", "end"}}
        """
        query = (
            f'cpg.method'
            f'.filter(_.filename.contains("{file_path}"))'
            f'.filter(m => m.lineNumber.getOrElse(-1) <= {line} '
            f'&& m.lineNumberEnd.getOrElse(-1) >= {line})'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"full_name" -> m.fullName, '
            f'"start_line" -> m.lineNumber.getOrElse(-1).toString, '
            f'"end_line" -> m.lineNumberEnd.getOrElse(-1).toString, '
            f'"file" -> m.filename'
            f')).toJson'
        )
        raw = self._execute(query)

        return {
            "file": file_path,
            "line": line,
            "method": raw.strip()[:500]
        }

    # ─── Tool 14: Get Call Graph Neighborhood ───

    def get_call_neighborhood(self, method_name: str, depth: int = 2) -> dict:
        """
        Get the call graph neighborhood around a method — both callers
        and callees up to N levels deep.

        USE WHEN: You want a bird's-eye view of how a method fits
        into the broader code flow before diving into specifics.

        Args:
            method_name: Center method
            depth: How many levels to expand (default 2)

        Returns:
            {"center": str, "callers": [...], "callees": [...]}
        """
        callers_query = (
            f'cpg.method.name("{method_name}").repeat(_.caller)(_.maxDepth({depth}))'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename'
            f')).dedup.toJson'
        )
        callees_query = (
            f'cpg.method.name("{method_name}").repeat(_.callee)(_.maxDepth({depth}))'
            f'.filterNot(_.isExternal)'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename'
            f')).dedup.toJson'
        )

        callers = self._execute(callers_query)
        callees = self._execute(callees_query)

        return {
            "center": method_name,
            "depth": depth,
            "callers_chain": callers.strip()[:1500],
            "callees_chain": callees.strip()[:1500],
            "_hint": (
                "This gives you the full call chain around the method. "
                "Look for HTTP entry points in callers and dangerous sinks in callees."
            )
        }

    # ─── Tool Definitions for LLM ───

    @staticmethod
    def get_tool_definitions() -> list:
        """
        Returns tool definitions in the format expected by LLM function calling.
        Pass these to the LLM so it knows what tools are available.
        """
        return [
            {
                "name": "joern_get_method_source",
                "description": (
                    "Get the full source code of a method. Use this as your FIRST "
                    "step to read and understand what a flagged function does."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {
                            "type": "string",
                            "description": "Name of the method (e.g., 'findUser', 'processRequest')"
                        }
                    },
                    "required": ["method_name"]
                }
            },
            {
                "name": "joern_get_callers",
                "description": (
                    "Find all methods that CALL the target method. Use to trace "
                    "BACKWARD — find where data comes from."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {
                            "type": "string",
                            "description": "Method to find callers for"
                        }
                    },
                    "required": ["method_name"]
                }
            },
            {
                "name": "joern_get_callees",
                "description": (
                    "Find all methods CALLED BY the target method. Use to trace "
                    "FORWARD — find where data goes and what operations are performed."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {
                            "type": "string",
                            "description": "Method to find callees for"
                        }
                    },
                    "required": ["method_name"]
                }
            },
            {
                "name": "joern_get_parameters",
                "description": (
                    "Get parameter names and types for a method. Use to check "
                    "what data a method receives and if String types could carry taint."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {
                            "type": "string",
                            "description": "Method to get parameters for"
                        }
                    },
                    "required": ["method_name"]
                }
            },
            {
                "name": "joern_find_taint_flow",
                "description": (
                    "THE KEY TOOL. Check if data flows from a source to a sink "
                    "across the entire codebase. Performs interprocedural, cross-file "
                    "taint tracking. Use after identifying potential source and sink."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "source_pattern": {
                            "type": "string",
                            "description": (
                                "Source method name — where untrusted data enters. "
                                "Examples: 'getParameter', 'getHeader', 'readLine', 'getInput'"
                            )
                        },
                        "sink_pattern": {
                            "type": "string",
                            "description": (
                                "Sink method name — where dangerous operation happens. "
                                "Examples: 'executeQuery', 'exec', 'eval', 'redirect', 'write'"
                            )
                        }
                    },
                    "required": ["source_pattern", "sink_pattern"]
                }
            },
            {
                "name": "joern_find_taint_flow_fullname",
                "description": (
                    "Like find_taint_flow but uses full qualified name regex. "
                    "Use when simple name matching is too broad."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "source_fullname": {
                            "type": "string",
                            "description": "Regex for source (e.g., 'javax.servlet.*getParameter.*')"
                        },
                        "sink_fullname": {
                            "type": "string",
                            "description": "Regex for sink (e.g., 'java.sql.Statement.execute.*')"
                        }
                    },
                    "required": ["source_fullname", "sink_fullname"]
                }
            },
            {
                "name": "joern_check_sanitization",
                "description": (
                    "Check if a taint flow passes through a sanitization function. "
                    "Use AFTER confirming a flow exists to check if it's actually safe."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "source_pattern": {
                            "type": "string",
                            "description": "Source method name"
                        },
                        "sink_pattern": {
                            "type": "string",
                            "description": "Sink method name"
                        },
                        "sanitizer_pattern": {
                            "type": "string",
                            "description": (
                                "Regex matching sanitizer names. "
                                "Examples: 'sanitize|escape|validate|encode|clean|purify'"
                            )
                        }
                    },
                    "required": ["source_pattern", "sink_pattern", "sanitizer_pattern"]
                }
            },
            {
                "name": "joern_get_assignments",
                "description": (
                    "Find all assignments to a variable within a method. "
                    "Use to track how data is transformed between source and sink."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "variable": {"type": "string", "description": "Variable name"},
                        "method_name": {"type": "string", "description": "Method scope"}
                    },
                    "required": ["variable", "method_name"]
                }
            },
            {
                "name": "joern_get_usages",
                "description": (
                    "Find all places where a symbol is referenced. "
                    "Use to find if tainted data reaches multiple sinks."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "symbol": {"type": "string", "description": "Symbol name to search"},
                        "method_name": {
                            "type": "string",
                            "description": "Optional method scope (omit for global search)"
                        }
                    },
                    "required": ["symbol"]
                }
            },
            {
                "name": "joern_get_imports",
                "description": (
                    "Get imports in a file. Use to check what sanitization "
                    "libraries or security frameworks are available."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "File path (partial match, e.g., 'UserService.java')"
                        }
                    },
                    "required": ["file_path"]
                }
            },
            {
                "name": "joern_get_annotations",
                "description": (
                    "Get annotations/decorators on a method. Use to check for "
                    "security annotations like @PreAuthorize, @Valid, @Sanitized."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {"type": "string", "description": "Method to check"}
                    },
                    "required": ["method_name"]
                }
            },
            {
                "name": "joern_find_pattern",
                "description": (
                    "Search for a code pattern across the codebase. "
                    "Use to find all instances of a dangerous pattern."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Code pattern regex (e.g., 'executeQuery', 'Runtime.exec')"
                        },
                        "file_pattern": {
                            "type": "string",
                            "description": "Optional file filter regex (default: all files)"
                        }
                    },
                    "required": ["pattern"]
                }
            },
            {
                "name": "joern_get_method_at_location",
                "description": (
                    "Find which method contains a specific line of code. "
                    "Use when Agent 1 gives you a file:line reference."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "File path (partial match)"},
                        "line": {"type": "integer", "description": "Line number"}
                    },
                    "required": ["file_path", "line"]
                }
            },
            {
                "name": "joern_get_call_neighborhood",
                "description": (
                    "Get the call graph neighborhood around a method — both callers "
                    "and callees up to N levels deep. Use for a bird's-eye view "
                    "before diving into specifics."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "method_name": {"type": "string", "description": "Center method"},
                        "depth": {
                            "type": "integer",
                            "description": "Levels to expand (default: 2, max: 4)"
                        }
                    },
                    "required": ["method_name"]
                }
            }
        ]

    def dispatch_tool_call(self, tool_name: str, arguments: dict) -> dict:
        """
        Route an LLM tool call to the correct method.

        This is the main entry point your agent orchestrator calls
        when the LLM requests a tool.

        Args:
            tool_name: The tool name from the LLM (e.g., "joern_find_taint_flow")
            arguments: The arguments dict from the LLM

        Returns:
            Structured result dict
        """
        tool_map = {
            "joern_get_method_source": lambda a: self.get_method_source(a["method_name"]),
            "joern_get_callers": lambda a: self.get_callers(a["method_name"]),
            "joern_get_callees": lambda a: self.get_callees(a["method_name"]),
            "joern_get_parameters": lambda a: self.get_parameters(a["method_name"]),
            "joern_find_taint_flow": lambda a: self.find_taint_flow(a["source_pattern"], a["sink_pattern"]),
            "joern_find_taint_flow_fullname": lambda a: self.find_taint_flow_fullname(a["source_fullname"], a["sink_fullname"]),
            "joern_check_sanitization": lambda a: self.check_sanitization(a["source_pattern"], a["sink_pattern"], a["sanitizer_pattern"]),
            "joern_get_assignments": lambda a: self.get_assignments(a["variable"], a["method_name"]),
            "joern_get_usages": lambda a: self.get_usages(a["symbol"], a.get("method_name")),
            "joern_get_imports": lambda a: self.get_imports(a["file_path"]),
            "joern_get_annotations": lambda a: self.get_annotations(a["method_name"]),
            "joern_find_pattern": lambda a: self.find_pattern(a["pattern"], a.get("file_pattern", ".*")),
            "joern_get_method_at_location": lambda a: self.get_method_at_location(a["file_path"], a["line"]),
            "joern_get_call_neighborhood": lambda a: self.get_call_neighborhood(a["method_name"], a.get("depth", 2)),
        }

        handler = tool_map.get(tool_name)
        if not handler:
            return {"error": f"Unknown tool: {tool_name}"}

        try:
            return handler(arguments)
        except Exception as e:
            logger.error(f"Tool {tool_name} failed: {e}")
            return {"error": str(e), "tool": tool_name, "arguments": arguments}


# ─── Quick Test ───

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python joern_scaffolding.py /path/to/repo [language]")
        print("")
        print("Prerequisites:")
        print("  1. brew install joern")
        print("  2. pip install cpgqls-client")
        print("  3. Start server: joern --server --server-host localhost --server-port 8080")
        print("")
        print("Then: python joern_scaffolding.py /path/to/java/project javasrc")
        sys.exit(1)

    repo_path = sys.argv[1]
    language = sys.argv[2] if len(sys.argv) > 2 else "javasrc"

    joern = JoernScaffold()

    print(f"\n[1] Importing code from {repo_path} (language: {language})...")
    result = joern.import_code(repo_path, language=language)
    print(f"    Result: {result}")

    print("\n[2] Listing all methods...")
    methods = joern._execute("cpg.method.name.l.take(20)")
    print(f"    Methods: {methods[:500]}")

    print("\n[3] Tool definitions for LLM:")
    tools = joern.get_tool_definitions()
    for t in tools:
        print(f"    - {t['name']}: {t['description'][:80]}...")

    print("\n[4] Ready for LLM tool calls. Example:")
    print('    joern.dispatch_tool_call("joern_get_callers", {"method_name": "main"})')
