"""
Joern Scaffolding Layer — Agno Toolkit Edition
================================================

This module wraps Joern's Code Property Graph (CPG) queries as an Agno Toolkit,
so an Agent can call them directly as tools during security analysis.

Setup:
  brew install joern
  pip install cpgqls-client agno

Start Joern server:
  joern --server --server-host localhost --server-port 8080

Usage with Agno Agent:
  from agno.agent import Agent
  from agno.models.anthropic import Claude
  from joern_scaffolding import JoernTools

  joern = JoernTools(host="localhost", port=8080)
  joern.load_project("/path/to/repo", language="javasrc")

  agent = Agent(
      model=Claude(id="claude-sonnet-4-5-20250929"),
      tools=[joern],
      instructions=[...],
  )
  agent.print_response("Analyze findUser for SQL injection", stream=True)

Standalone usage (without Agno):
  from joern_scaffolding import JoernTools
  joern = JoernTools()
  joern.load_project("/path/to/repo", language="javasrc")
  print(joern.get_method_source(method_name="findUser"))
"""

import json
import re
import logging
from typing import Optional, List
from cpgqls_client import CPGQLSClient, import_code_query

from agno.tools import Toolkit
from agno.utils.log import logger as agno_logger

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("joern_tools")


# ─── Main Toolkit ───

class JoernTools(Toolkit):
    """
    Agno Toolkit that exposes Joern CPG queries as LLM-callable tools.

    Each public method becomes a tool the LLM can invoke. Agno reads the
    method's docstring + type hints to build the function-calling schema
    automatically — no manual get_tool_definitions() or dispatch_tool_call()
    needed.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 8080,
        auth: tuple = None,
        **kwargs,
    ):
        # Register every tool method with the Agno Toolkit base class.
        # Order here controls the order the LLM sees them.
        tools = [
            self.get_method_source,
            self.get_callers,
            self.get_callees,
            self.get_parameters,
            self.find_taint_flow,
            self.find_taint_flow_fullname,
            self.check_sanitization,
            self.get_assignments,
            self.get_usages,
            self.get_imports,
            self.get_annotations,
            self.find_pattern,
            self.get_method_at_location,
            self.get_call_neighborhood,
        ]

        super().__init__(name="joern_tools", tools=tools, **kwargs)

        # Connect to running Joern server
        endpoint = f"{host}:{port}"
        self.client = CPGQLSClient(endpoint, auth_credentials=auth)
        self._project_loaded = False
        logger.info(f"JoernTools connected to Joern server at {endpoint}")

    # ─── Internal Helpers (not exposed as tools) ───

    def _execute(self, query: str) -> str:
        """Execute a Joern query and return raw stdout."""
        logger.debug(f"Joern query: {query}")
        try:
            result = self.client.execute(query)
            raw = result.get("stdout", "") if isinstance(result, dict) else str(result)
            logger.debug(f"Joern result: {raw[:200]}")
            return raw
        except Exception as e:
            logger.error(f"Joern query failed: {e}")
            return ""

    def _parse_bool(self, raw: str) -> bool:
        return "true" in raw.strip().lower()

    # ─── Project Management (called by orchestrator, not by LLM) ───

    def load_project(self, path: str, language: str = "javasrc",
                     project_name: str = "analysis") -> dict:
        """
        Import a codebase and build the CPG. Call this from your orchestrator
        BEFORE giving the agent a task — this is NOT an LLM tool.

        Args:
            path: Absolute path to the cloned repository.
            language: Language frontend (javasrc, jssrc, pysrc, c, etc.)
            project_name: Workspace name.

        Returns:
            {"success": bool, "message": str}
        """
        query = import_code_query(path, project_name)
        result = self._execute(query)
        self._project_loaded = "cpg" in result.lower()
        return {
            "success": self._project_loaded,
            "message": result.strip()[:200],
        }

    def close_project(self) -> dict:
        """Unload the current CPG and free memory."""
        self._execute("workspace.reset")
        self._project_loaded = False
        return {"success": True, "message": "Workspace reset"}

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    #  TOOLS — every method below is callable by the LLM
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    # ─── Tool 1: Get Method Source ───

    def get_method_source(self, method_name: str) -> str:
        """
        Get the full source code of a method by name.

        Use this as your FIRST step to read and understand what a flagged
        function does — identify variables, calls, and logic.

        Args:
            method_name (str): Name of the method, e.g. "findUser" or "processRequest".

        Returns:
            str: JSON with method name, file location, line number, and full source code.
        """
        query = (
            f'cpg.method.name("{method_name}")'
            f'.map(m => (m.name, m.filename, m.lineNumber.getOrElse(-1), m.code)).l'
        )
        raw = self._execute(query)

        body_query = (
            f'cpg.method.name("{method_name}").ast.code.l.mkString("\\n")'
        )
        body = self._execute(body_query)

        return json.dumps({
            "name": method_name,
            "info": raw.strip()[:500],
            "source": body.strip()[:2000],
            "_hint": "Read the source to identify variables, calls, and data flow patterns",
        })

    # ─── Tool 2: Get Callers ───

    def get_callers(self, method_name: str) -> str:
        """
        Find all methods that CALL the target method.

        Use to trace BACKWARD — "where does the data come from?"
        After finding a dangerous sink, use this to find who passes data to it.

        Args:
            method_name (str): Name of the method to find callers for.

        Returns:
            str: JSON with the list of caller methods and their call-site code.
        """
        query = (
            f'cpg.method.name("{method_name}").caller'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename, '
            f'"line" -> m.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        raw = self._execute(query)

        callsite_query = (
            f'cpg.method.name("{method_name}").callIn'
            f'.map(c => Map('
            f'"caller_method" -> c.method.name, '
            f'"code" -> c.code, '
            f'"file" -> c.file.name.headOption.getOrElse("unknown"), '
            f'"line" -> c.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        callsites = self._execute(callsite_query)

        return json.dumps({
            "method": method_name,
            "callers": raw.strip()[:1000],
            "call_sites": callsites.strip()[:1000],
            "_hint": "To continue tracing backward, call get_method_source on each caller",
        })

    # ─── Tool 3: Get Callees ───

    def get_callees(self, method_name: str) -> str:
        """
        Find all methods CALLED BY the target method.

        Use to trace FORWARD — "where does the data go?"
        Helps understand what operations a method performs.

        Args:
            method_name (str): Name of the method to find callees for.

        Returns:
            str: JSON with internal callees and all calls (including external/library).
        """
        query = (
            f'cpg.method.name("{method_name}").callee'
            f'.filterNot(_.isExternal)'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename, '
            f'"line" -> m.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        raw = self._execute(query)

        ext_query = (
            f'cpg.method.name("{method_name}").call'
            f'.map(c => Map('
            f'"name" -> c.name, '
            f'"code" -> c.code, '
            f'"line" -> c.lineNumber.getOrElse(-1).toString'
            f')).toJson'
        )
        ext_calls = self._execute(ext_query)

        return json.dumps({
            "method": method_name,
            "internal_callees": raw.strip()[:1000],
            "all_calls": ext_calls.strip()[:1500],
            "_hint": "Look for dangerous sinks: execute, eval, exec, open, redirect, write",
        })

    # ─── Tool 4: Get Parameters ───

    def get_parameters(self, method_name: str) -> str:
        """
        Get parameter names and types for a method.

        Use to check what data a method receives and whether String-typed
        parameters could carry tainted input.

        Args:
            method_name (str): Name of the method.

        Returns:
            str: JSON with list of parameters, their types, and indices.
        """
        query = (
            f'cpg.method.name("{method_name}").parameter'
            f'.map(p => Map('
            f'"name" -> p.name, '
            f'"type" -> p.typeFullName, '
            f'"index" -> p.index.toString'
            f')).toJson'
        )
        raw = self._execute(query)

        return json.dumps({
            "method": method_name,
            "parameters": raw.strip()[:1000],
            "_hint": "Check if any parameter type is String — those can carry tainted data",
        })

    # ─── Tool 5: Find Taint Flow (THE KEY TOOL) ───

    def find_taint_flow(self, source_pattern: str, sink_pattern: str) -> str:
        """
        THE KEY TOOL. Check if data flows from a source to a sink across the codebase.

        This does cross-file interprocedural taint tracking automatically.
        Use when you have identified a potential source (e.g. getParameter)
        and a potential sink (e.g. executeQuery) and want to know if tainted
        data can actually reach the sink.

        Args:
            source_pattern (str): Name pattern for the source method, e.g. "getParameter", "getHeader", "readLine".
            sink_pattern (str): Name pattern for the sink method, e.g. "executeQuery", "exec", "eval", "redirect".

        Returns:
            str: JSON with flow_exists boolean and detailed flow paths if found.
        """
        exists_query = (
            f'def source = cpg.call.name("{source_pattern}")\\n'
            f'def sink = cpg.call.name("{sink_pattern}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        exists_raw = self._execute(exists_query)
        flow_exists = self._parse_bool(exists_raw)

        paths = []
        if flow_exists:
            flow_query = (
                f'def source = cpg.call.name("{source_pattern}")\\n'
                f'def sink = cpg.call.name("{sink_pattern}")\\n'
                f'sink.reachableBy(source).flows'
                f'.map(f => f.elements.map(e => Map('
                f'"code" -> e.code, '
                f'"line" -> e.lineNumber.getOrElse(-1).toString, '
                f'"file" -> e.file.name.headOption.getOrElse("unknown"), '
                f'"node_type" -> e.label'
                f'))).toJson'
            )
            paths = self._execute(flow_query).strip()[:3000]

        return json.dumps({
            "source_pattern": source_pattern,
            "sink_pattern": sink_pattern,
            "flow_exists": flow_exists,
            "paths": paths if paths else "No flow found",
            "_hint": (
                "If flow_exists is true, examine the path to understand how data "
                "moves from source to sink. If false, the concern is likely a false positive."
            ),
        })

    # ─── Tool 6: Find Taint Flow with Full Name Matching ───

    def find_taint_flow_fullname(self, source_fullname: str,
                                  sink_fullname: str) -> str:
        """
        Like find_taint_flow but uses full method name regex matching.

        Use when simple name matching returns too many results or you need
        to target a specific class or package.

        Args:
            source_fullname (str): Regex for source full name, e.g. "javax.servlet.*getParameter.*".
            sink_fullname (str): Regex for sink full name, e.g. "java.sql.Statement.execute.*".

        Returns:
            str: JSON with flow_exists boolean and detailed flow paths.
        """
        exists_query = (
            f'def source = cpg.call.methodFullName("{source_fullname}")\\n'
            f'def sink = cpg.call.methodFullName("{sink_fullname}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        exists_raw = self._execute(exists_query)
        flow_exists = self._parse_bool(exists_raw)

        paths = []
        if flow_exists:
            flow_query = (
                f'def source = cpg.call.methodFullName("{source_fullname}")\\n'
                f'def sink = cpg.call.methodFullName("{sink_fullname}")\\n'
                f'sink.reachableBy(source).flows'
                f'.map(f => f.elements.map(e => Map('
                f'"code" -> e.code, '
                f'"line" -> e.lineNumber.getOrElse(-1).toString, '
                f'"file" -> e.file.name.headOption.getOrElse("unknown")'
                f'))).toJson'
            )
            paths = self._execute(flow_query).strip()[:3000]

        return json.dumps({
            "source_pattern": source_fullname,
            "sink_pattern": sink_fullname,
            "flow_exists": flow_exists,
            "paths": paths if paths else "No flow found",
        })

    # ─── Tool 7: Check Sanitization ───

    def check_sanitization(self, source_pattern: str, sink_pattern: str,
                           sanitizer_pattern: str) -> str:
        """
        Check if a taint flow passes through a sanitization function.

        Use when you have confirmed a flow exists and want to check if
        a sanitizer in the path makes it safe. Remember: the sanitizer
        must match the sink type (HTML-encoding does NOT prevent SQLi).

        Args:
            source_pattern (str): Source method name, e.g. "getParameter".
            sink_pattern (str): Sink method name, e.g. "executeQuery".
            sanitizer_pattern (str): Regex matching sanitizer names, e.g. "sanitize|escape|validate|encode|clean|purify".

        Returns:
            str: JSON with flow_exists, passes_through_sanitizer, and a verdict.
        """
        exists_query = (
            f'def source = cpg.call.name("{source_pattern}")\\n'
            f'def sink = cpg.call.name("{sink_pattern}")\\n'
            f'sink.reachableBy(source).flows.l.nonEmpty'
        )
        flow_exists = self._parse_bool(self._execute(exists_query))

        passes_sanitizer = False
        if flow_exists:
            sanitized_query = (
                f'def source = cpg.call.name("{source_pattern}")\\n'
                f'def sink = cpg.call.name("{sink_pattern}")\\n'
                f'sink.reachableBy(source).flows'
                f'.filter(_.elements.isCall.name("{sanitizer_pattern}").nonEmpty)'
                f'.l.nonEmpty'
            )
            passes_sanitizer = self._parse_bool(self._execute(sanitized_query))

        return json.dumps({
            "source": source_pattern,
            "sink": sink_pattern,
            "sanitizer": sanitizer_pattern,
            "flow_exists": flow_exists,
            "passes_through_sanitizer": passes_sanitizer,
            "verdict": (
                "SAFE — flow passes through sanitizer" if passes_sanitizer
                else "VULNERABLE — flow exists without sanitization"
                if flow_exists else "NO FLOW — no data path from source to sink"
            ),
            "_hint": (
                "If VULNERABLE, report as confirmed finding. "
                "If SAFE, verify the sanitizer is appropriate for the sink type "
                "(e.g., HTML encoding doesn't prevent SQLi)."
            ),
        })

    # ─── Tool 8: Get Assignments ───

    def get_assignments(self, variable: str, method_name: str) -> str:
        """
        Find all assignments to a variable within a method.

        Use to track how a variable is transformed between source and sink.
        Look for string concatenation with tainted variables or re-assignment
        after sanitization (sanitize-then-modify pattern).

        Args:
            variable (str): Variable name to track, e.g. "query" or "userId".
            method_name (str): Method to search within.

        Returns:
            str: JSON with list of assignments showing code and line numbers.
        """
        query = (
            f'cpg.method.name("{method_name}").ast.isCall'
            f'.name("<operator>.assignment")'
            f'.filter(_.argument(1).code(".*{variable}.*"))'
            f'.map(a => Map('
            f'"code" -> a.code, '
            f'"line" -> a.lineNumber.getOrElse(-1).toString, '
            f'"file" -> a.file.name.headOption.getOrElse("unknown")'
            f')).toJson'
        )
        raw = self._execute(query)

        return json.dumps({
            "variable": variable,
            "method": method_name,
            "assignments": raw.strip()[:1500],
            "_hint": (
                "Look for string concatenation with tainted variables, "
                "or re-assignment after sanitization (sanitize-then-modify pattern)"
            ),
        })

    # ─── Tool 9: Get Usages ───

    def get_usages(self, symbol: str, method_name: str = "") -> str:
        """
        Find all places where a symbol (variable or method) is referenced.

        Use to check if a tainted variable reaches multiple sinks.

        Args:
            symbol (str): Symbol name to search for.
            method_name (str): Optional — restrict search to a specific method. Leave empty for global search.

        Returns:
            str: JSON with list of usages showing code, line, file, and method.
        """
        if method_name:
            query = (
                f'cpg.method.name("{method_name}").ast.isIdentifier'
                f'.name("{symbol}")'
                f'.map(i => Map('
                f'"code" -> i.inAstMinusLeaf.headOption.map(_.code).getOrElse(i.code), '
                f'"line" -> i.lineNumber.getOrElse(-1).toString, '
                f'"file" -> i.file.name.headOption.getOrElse("unknown")'
                f')).toJson'
            )
        else:
            query = (
                f'cpg.identifier.name("{symbol}")'
                f'.map(i => Map('
                f'"code" -> i.inAstMinusLeaf.headOption.map(_.code).getOrElse(i.code), '
                f'"line" -> i.lineNumber.getOrElse(-1).toString, '
                f'"file" -> i.file.name.headOption.getOrElse("unknown"), '
                f'"method" -> i.method.name'
                f')).toJson'
            )
        raw = self._execute(query)

        return json.dumps({
            "symbol": symbol,
            "scope": method_name or "global",
            "usages": raw.strip()[:2000],
        })

    # ─── Tool 10: Get Imports ───

    def get_imports(self, file_path: str) -> str:
        """
        Get all imports/includes in a file.

        Use to check what sanitization libraries or frameworks are available.
        Also useful for identifying if an ORM or security wrapper is in use.

        Args:
            file_path (str): File path or partial filename, e.g. "UserService.java".

        Returns:
            str: JSON with list of import statements found in the file.
        """
        query = (
            f'cpg.file.name(".*{file_path}.*").ast.isCall'
            f'.name("<operator>.import")'
            f'.code.l'
        )
        raw = self._execute(query)

        if not raw.strip() or "List()" in raw:
            query = (
                f'cpg.file.name(".*{file_path}.*")'
                f'.ast.filter(_.label == "IMPORT")'
                f'.code.l'
            )
            raw = self._execute(query)

        return json.dumps({
            "file": file_path,
            "imports": raw.strip()[:2000],
            "_hint": (
                "Look for security-related imports: sanitizers, validators, "
                "ORM libraries, prepared statement classes"
            ),
        })

    # ─── Tool 11: Get Decorators / Annotations ───

    def get_annotations(self, method_name: str) -> str:
        """
        Get annotations or decorators on a method.

        Use to check for security annotations like @Validated, @Sanitized,
        @PreAuthorize, @RolesAllowed, etc. that indicate framework-level protection.

        Args:
            method_name (str): Method to check for annotations.

        Returns:
            str: JSON with list of annotations found on the method.
        """
        query = (
            f'cpg.method.name("{method_name}").annotation'
            f'.map(a => Map('
            f'"name" -> a.name, '
            f'"code" -> a.code'
            f')).toJson'
        )
        raw = self._execute(query)

        return json.dumps({
            "method": method_name,
            "annotations": raw.strip()[:1000],
            "_hint": (
                "Security annotations like @PreAuthorize, @Valid, @Sanitized "
                "may indicate framework-level protection"
            ),
        })

    # ─── Tool 12: Find Pattern ───

    def find_pattern(self, pattern: str, file_pattern: str = ".*") -> str:
        """
        Search for a code pattern across the codebase.

        Use to find all instances of a dangerous pattern like raw SQL
        construction, eval usage, or hardcoded secrets.

        Args:
            pattern (str): Code pattern to search for (regex), e.g. "executeQuery" or "Runtime.exec".
            file_pattern (str): Optional file path filter regex. Defaults to all files.

        Returns:
            str: JSON with list of matches showing code, line, file, and containing method.
        """
        query = (
            f'cpg.call.code(".*{pattern}.*")'
            f'.filter(_.file.name(".*{file_pattern}.*"))'
            f'.map(c => Map('
            f'"code" -> c.code, '
            f'"line" -> c.lineNumber.getOrElse(-1).toString, '
            f'"file" -> c.file.name.headOption.getOrElse("unknown"), '
            f'"method" -> c.method.name'
            f')).toJson'
        )
        raw = self._execute(query)

        return json.dumps({
            "pattern": pattern,
            "file_filter": file_pattern,
            "matches": raw.strip()[:2000],
        })

    # ─── Tool 13: Get Method by File and Line ───

    def get_method_at_location(self, file_path: str, line: int) -> str:
        """
        Find which method contains a specific line of code.

        Use when Agent 1 gives you a file:line reference and you need to
        know which method it belongs to.

        Args:
            file_path (str): File path or partial match, e.g. "UserService.java".
            line (int): Line number in the file.

        Returns:
            str: JSON with the method name, full name, start line, end line, and file.
        """
        query = (
            f'cpg.method'
            f'.filter(_.filename.contains("{file_path}"))'
            f'.filter(m => m.lineNumber.getOrElse(-1) <= {line} '
            f'&& m.lineNumberEnd.getOrElse(-1) >= {line})'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"full_name" -> m.fullName, '
            f'"start_line" -> m.lineNumber.getOrElse(-1).toString, '
            f'"end_line" -> m.lineNumberEnd.getOrElse(-1).toString, '
            f'"file" -> m.filename'
            f')).toJson'
        )
        raw = self._execute(query)

        return json.dumps({
            "file": file_path,
            "line": line,
            "method": raw.strip()[:500],
        })

    # ─── Tool 14: Get Call Graph Neighborhood ───

    def get_call_neighborhood(self, method_name: str, depth: int = 2) -> str:
        """
        Get the call graph neighborhood around a method — both callers
        and callees up to N levels deep.

        Use for a bird's-eye view of how a method fits into the broader
        code flow before diving into specifics. Look for HTTP entry points
        in callers and dangerous sinks in callees.

        Args:
            method_name (str): Center method to explore around.
            depth (int): How many levels to expand (default 2, max 4).

        Returns:
            str: JSON with callers_chain and callees_chain around the method.
        """
        depth = min(depth, 4)

        callers_query = (
            f'cpg.method.name("{method_name}").repeat(_.caller)(_.maxDepth({depth}))'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename'
            f')).dedup.toJson'
        )
        callees_query = (
            f'cpg.method.name("{method_name}").repeat(_.callee)(_.maxDepth({depth}))'
            f'.filterNot(_.isExternal)'
            f'.map(m => Map('
            f'"name" -> m.name, '
            f'"file" -> m.filename'
            f')).dedup.toJson'
        )

        callers = self._execute(callers_query)
        callees = self._execute(callees_query)

        return json.dumps({
            "center": method_name,
            "depth": depth,
            "callers_chain": callers.strip()[:1500],
            "callees_chain": callees.strip()[:1500],
            "_hint": (
                "This gives you the full call chain around the method. "
                "Look for HTTP entry points in callers and dangerous sinks in callees."
            ),
        })


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  Example: wire up an Agno Agent with JoernTools
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python joern_scaffolding.py /path/to/repo [language]")
        print()
        print("Prerequisites:")
        print("  1. brew install joern")
        print("  2. pip install cpgqls-client agno")
        print("  3. Start server: joern --server --server-host localhost --server-port 8080")
        print()
        print("Then: python joern_scaffolding.py /path/to/java/project javasrc")
        sys.exit(1)

    repo_path = sys.argv[1]
    language = sys.argv[2] if len(sys.argv) > 2 else "javasrc"

    # ── 1. Create toolkit and load project ──
    joern = JoernTools()
    print(f"\n[1] Importing code from {repo_path} (language: {language})...")
    result = joern.load_project(repo_path, language=language)
    print(f"    Result: {result}")

    if not result["success"]:
        print("    ❌ Failed to load project. Is Joern server running?")
        sys.exit(1)

    # ── 2. Quick standalone test ──
    print("\n[2] Standalone tool call test:")
    source = joern.get_method_source(method_name="main")
    print(f"    get_method_source('main'): {source[:200]}...")

    # ── 3. Wire into Agno Agent ──
    print("\n[3] Creating Agno Agent with JoernTools...")
    try:
        from agno.agent import Agent
        from agno.models.anthropic import Claude

        agent = Agent(
            model=Claude(id="claude-sonnet-4-5-20250929"),
            tools=[joern],
            instructions=[
                "You are a security analyst. Use the Joern tools to analyze code for vulnerabilities.",
                "Always trace taint paths from source to sink before reporting a finding.",
                "Every claim must be backed by a tool call result.",
            ],
            show_tool_calls=True,
            markdown=True,
        )

        print("    ✅ Agent created. Running sample analysis...")
        agent.print_response(
            "List all methods in the project and identify any that take String parameters",
            stream=True,
        )
    except ImportError:
        print("    ⚠  agno not installed — skipping Agent demo")
        print("    Install with: pip install agno")
    except Exception as e:
        print(f"    ⚠  Agent creation failed: {e}")
        print("    (This is expected if ANTHROPIC_API_KEY is not set)")
