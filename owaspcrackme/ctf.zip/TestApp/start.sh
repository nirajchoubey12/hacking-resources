#!/bin/bash
app="docker.flask"
docker build -t ${app} .
docker run -d -p 8001:80 \
  --name=${app} \
  -v $PWD:/app ${app}

