const url = '/search'

$('.search-btn').click(function(){

    $.get(url, function(data, status){
     
        document.getElementById("score").innerText = `${data}`;  
     });

})

