from flask import render_template, render_template_string, request
from app import app
import re
import random

@app.route('/')
def index():
    
    return render_template('index.html')


@app.route('/search')
def search():

    payload = request.args.get('payload')

    if payload is None:
        return "I was expecting something"

    blacklist = ['config', 'self','mro','request.environ', 'shutdown','config','url_for','+','<','>','script','img','_','[',']','5f']
    payload = re.sub('[_\]\[]','',payload)
    payload = payload.replace('x5f','')

    for bad_string in blacklist:
        if bad_string in payload:
            return 'Hacking attempt detected {} is prohibited'.format(bad_string)
    #payload = re.sub('[_]','',payload)
    print(payload)
    num = random.randint(0, 200)
    
    hint = 'Gone in a flash'
    
    #renderd_template = render_template("app.html", payload=payload)
    if payload:
         renderd_template = '{} your score is {}. {template}'.format(payload, num, template=hint if num>100 else '')
    else:
         renderd_template = 'Man with No name'
   
    print(renderd_template)

    return render_template_string(renderd_template)
    #return "not starteing"
@app.route('/home')
def home():
    return render_template('home.html')
